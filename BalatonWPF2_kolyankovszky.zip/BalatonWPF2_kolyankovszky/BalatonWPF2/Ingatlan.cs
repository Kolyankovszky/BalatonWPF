﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BalatonWPF2
{
    public class Ingatlan
    {
        public string Adoszam { get; private set; }
        public string UtcaNev { get; private set; }
        public string HazSzam { get; private set; }
        public string AdoSav { get; set; }
        public int Terulet { get; private set; }

        public Ingatlan(string sor)
        {
            string[] darabok = sor.Split(' ');
            Adoszam = darabok[0];
            UtcaNev = darabok[1];
            HazSzam = darabok[2];
            AdoSav = darabok[3];
            Terulet = Convert.ToInt32(darabok[4]);
        }
    }
}
