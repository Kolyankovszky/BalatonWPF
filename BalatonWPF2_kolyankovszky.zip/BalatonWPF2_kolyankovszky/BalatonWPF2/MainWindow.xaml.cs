﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace BalatonWPF2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static List<Ingatlan> ingatlanLista = new List<Ingatlan>();
        public static int A;
        public static int B;
        public static int C;
        public MainWindow()
        {
            InitializeComponent();

            StreamReader sr = new StreamReader("utca.txt");
            string[] ado = sr.ReadLine().Split(' ');
            A = int.Parse(ado[0]);
            B = int.Parse(ado[1]);
            C = int.Parse(ado[2]);
            while (!sr.EndOfStream)
            {
                ingatlanLista.Add(new Ingatlan(sr.ReadLine()));
            }
            sr.Close();

            DataGrid.ItemsSource = ingatlanLista;
            DataGrid.Items.Refresh();

            ComboBox.Items.Add("A");
            ComboBox.Items.Add("B");
            ComboBox.Items.Add("C");
        }

        private void BtnPut_Click(object sender, RoutedEventArgs e)
        {
            string comboBoxValue = ComboBox.SelectedItem.ToString();
            int dataGridRowIndex = DataGrid.SelectedIndex;
            ingatlanLista[dataGridRowIndex].AdoSav = comboBoxValue;
            DataGrid.Items.Refresh();
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                StreamWriter sw = new StreamWriter("modosit.txt");
                foreach (var item in ingatlanLista)
                {
                    sw.WriteLine(item.Adoszam + ' ' + item.UtcaNev + ' ' + item.HazSzam + ' ' + item.AdoSav + ' ' + item.Terulet);
                }
                sw.Close();
                MessageBox.Show("Sikeres mentés");
            }
            catch (Exception)
            {

                MessageBox.Show("Mentés sikertelen ");
            }
        }
    }
}
